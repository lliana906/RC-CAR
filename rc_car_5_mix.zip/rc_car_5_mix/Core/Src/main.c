/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Ultrasonic 3 sensors (TIM2 IC) + Bluetooth(UART1) + Auto drive
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ult.h"
#include "delay.h"
#include "auto.h"
#include "mot.h"
#include "bt.h"
#include <stdio.h>
/* USER CODE END Includes */

/* USER CODE BEGIN PD */
#define TRIG_PERIOD_MS   35    // ✅ 35ms마다 1회 트리거 (간섭 있으면 40)
#define AUTO_WARM_MS     400
/* USER CODE END PD */

/* USER CODE BEGIN PM */
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

PUTCHAR_PROTOTYPE
{
  if(ch == '\n')
    HAL_UART_Transmit(&huart1, (uint8_t*)"\r", 1, 0xFFFF);
  HAL_UART_Transmit(&huart1, (uint8_t*)&ch, 1, 0xFFFF);
  return ch;
}
/* USER CODE END PM */

/* USER CODE BEGIN PV */
static uint8_t bt_rx = 0;
/* USER CODE END PV */

void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        BT_OnRxByte(bt_rx);
        HAL_UART_Receive_IT(&huart1, &bt_rx, 1);
    }
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    ULT_TIM_IC_CaptureCallback(htim);
}
/* USER CODE END PFP */

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_USART2_UART_Init();   // 유지해도 됨
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_TIM11_Init();

  /* USER CODE BEGIN 2 */
  BT_Init();
  HAL_UART_Receive_IT(&huart1, &bt_rx, 1);

  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);

  HAL_TIM_Base_Start(&htim11);

  ULT_Init();

  printf("\r\nBOOT OK\r\n");
  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  static uint32_t last_trig_ms = 0;
  static uint32_t auto_warm_until = 0;

  static uint16_t d_left=0, d_front=0, d_right=0;

  static DriveMode_t last_mode = MODE_MANUAL;

  static uint32_t last_dbg_ms = 0;
  static uint32_t last_manual_ms = 0;

  // ✅ 전방을 더 자주: F-F-L-F-R
  static const uint8_t trig_seq[5] = {1, 1, 0, 1, 2};
  static uint8_t seq_i = 0;

  while (1)
  {
      uint32_t now = HAL_GetTick();

      BT_Process();
      DriveMode_t mode = BT_GetMode();

      if (mode != last_mode)
      {
          Mot_Stop();

          if (mode == MODE_AUTO)
          {
              Auto_Init();
              d_left = d_front = d_right = 0;

              seq_i = 0;
              last_trig_ms = now;
              auto_warm_until = now + AUTO_WARM_MS;

              printf("[MODE] AUTO\r\n");
          }
          else
          {
              printf("[MODE] MANUAL\r\n");
          }

          last_mode = mode;
      }

      if (mode == MODE_AUTO)
      {
          if (now < auto_warm_until)
          {
              Mot_Stop();
              continue;
          }

          // (1) 트리거
          if (now - last_trig_ms >= TRIG_PERIOD_MS)
          {
              last_trig_ms = now;
              ULT_Trigger(trig_seq[seq_i]);
              seq_i = (seq_i + 1) % 5;
          }

          // (2) 타임아웃 처리
          ULT_Update();

          // (3) 거리 갱신 (0도 갱신)
          if (ULT_IsReady(0)) { d_left  = ULT_GetDistance(0); ULT_ClearReady(0); }
          if (ULT_IsReady(1)) { d_front = ULT_GetDistance(1); ULT_ClearReady(1); }
          if (ULT_IsReady(2)) { d_right = ULT_GetDistance(2); ULT_ClearReady(2); }

          // (4) 자율주행
          Auto_Update(d_left, d_front, d_right);

          // (5) 디버그
          if (now - last_dbg_ms >= 500)
          {
              last_dbg_ms = now;
              uint32_t arr  = __HAL_TIM_GET_AUTORELOAD(&htim3);
              uint32_t ccr1 = __HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_1);
              uint32_t ccr2 = __HAL_TIM_GET_COMPARE(&htim3, TIM_CHANNEL_2);

              printf("[AUTO] L:%u F:%u R:%u | ARR:%lu CCR1:%lu CCR2:%lu\r\n",
                     d_left, d_front, d_right,
                     (unsigned long)arr, (unsigned long)ccr1, (unsigned long)ccr2);
          }
      }
      else
      {
          if (now - last_manual_ms >= 400)
          {
              last_manual_ms = now;
              printf("[MANUAL]\r\n");
          }
      }
  }
  /* USER CODE END WHILE */


  /* USER CODE END WHILE */
  /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file; (void)line;
}
#endif /* USE_FULL_ASSERT */
//void assert_failed(uint8_t *file, uint32_t line)
//{
//  /* USER CODE BEGIN 6 */
//  /* User can add his own implementation to report the file name and line number,
//     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
//  /* USER CODE END 6 */
//}
//#endif /* USE_FULL_ASSERT */
